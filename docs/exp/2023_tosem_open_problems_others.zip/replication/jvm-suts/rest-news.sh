#!/bin/bash

SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
source "$SCRIPT_DIR"/env.txt "$1" "$2" "$3"

"$JAVA_HOME_8"/bin/java -Xms1G -Xmx4G "$AGENT" -jar "$EMB_DIR"/rest-news-sut.jar  --server.port="$PORT"