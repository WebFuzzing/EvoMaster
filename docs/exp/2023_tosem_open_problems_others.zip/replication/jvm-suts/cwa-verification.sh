#!/bin/bash

SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
source "$SCRIPT_DIR"/env.txt "$1" "$2" "$3"

"$JAVA_HOME_11"/bin/java -Xms1G -Xmx4G "$AGENT" -jar "$EMB_DIR"/cwa-verification-sut.jar  --server.port="$PORT" --spring.profiles.active=local,external,internal --management.server.port=-1  --server.ssl.enabled=false