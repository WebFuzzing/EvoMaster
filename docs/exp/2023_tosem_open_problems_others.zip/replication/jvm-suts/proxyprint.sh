#!/bin/bash

SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
source "$SCRIPT_DIR"/env.txt "$1" "$2" "$3"

TMP_DIR=./tmp/tmp_proxyprint/temp_$PORT
mkdir -p $TMP_DIR

"$JAVA_HOME_8"/bin/java -Xms1G -Xmx4G -Ddocuments.path=$TMP_DIR "$AGENT" -jar "$EMB_DIR"/proxyprint-sut.jar  --server.port="$PORT" --spring.datasource.url="jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1;MVCC=true;" --spring.jpa.hibernate.ddl-auto=create-drop