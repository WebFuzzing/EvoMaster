#!/bin/bash

SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
source "$SCRIPT_DIR"/env.txt "$1" "$2" "$3"

MP=$(($PORT + 1))
CID=$(docker run -d --rm -p $MP:5432 --tmpfs /var/lib/postgresql/data:rw -e POSTGRES_HOST_AUTH_METHOD=trust postgres:9.4)

sleep 30

"$JAVA_HOME_8"/bin/java -Xms1G -Xmx4G "$AGENT" -Dspring.datasource.url="jdbc:postgresql://localhost:$MP/postgres?currentSchema=comments" -Dspring.datasource.username=postgres -Dspring.jpa.show-sql=false -Dspring.cache.type=none -Dspring.jmx.enabled=false -jar "$EMB_DIR"/ind0-sut.jar  --server.port="$PORT"

docker stop $CID
