#!/bin/bash

SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
source "$SCRIPT_DIR"/env.txt "$1" "$2" "$3"

TMP_DIR=./tmp/tmp_scout_api/temp_$PORT
mkdir -p $TMP_DIR

"$JAVA_HOME_8"/bin/java -Xms1G -Xmx4G "$AGENT" -jar -Ddw.server.connector.port=$PORT -Ddw.tempFolder=$TMP_DIR -Ddw.mediaFilesFolder=$TMP_DIR/media-files  "$EMB_DIR"/scout-api-sut.jar  server  $EMB_DIR/../jdk_8_maven/em/external/rest/scout-api/src/main/resources/scout_api_evomaster.yml