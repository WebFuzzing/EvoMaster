#!/bin/bash

SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
source "$SCRIPT_DIR"/env.txt "$1" "$2"

cd "$EMB_DIR"/disease-sh-api


RP=$(($PORT + 1))
CID=$(docker run -d --rm -p $RP:6379 --mount "type=bind,source=$EMB_DIR/disease-sh-api/em/db/dump.rdb,target=/data/dump.rdb"  redis:6.2.5)

sleep 30


PORT=$PORT REDIS_PORT=$RP c8 $OPTIONS  node src/serverStart.js

docker stop $CID