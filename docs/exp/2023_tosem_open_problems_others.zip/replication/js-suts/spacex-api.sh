#!/bin/bash

SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
source "$SCRIPT_DIR"/env.txt "$1" "$2"


MP=$(($PORT + 1))
CID=$(docker run -d --rm -p $MP:27017  mongo:3.5)

sleep 30

cd "$EMB_DIR"/spacex-api
PORT=$PORT SPACEX_MONGO=mongodb://localhost:$MP/spacex c8 $OPTIONS  node src/server.js

docker stop $CID