#!/bin/bash

SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
source "$SCRIPT_DIR"/env.txt "$1" "$2"


MP=$(($PORT + 1))
CID=$(docker run -d --rm -e MYSQL_ROOT_PASSWORD=test -e MYSQL_USER=test -e MYSQL_PASSWORD=test  -e MYSQL_DATABASE=test -p $MP:3306 mysql:5.7.22)

sleep 30

cd "$EMB_DIR"/realworld-app
PORT=$PORT NODE_ENV=production DB_PORT=$MP c8 $OPTIONS  node build/src/main.js

docker stop $CID