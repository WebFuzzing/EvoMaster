#!/usr/bin/python

import sys
import requests

if len(sys.argv) != 2:
    raise Exception("base url should be specified")

BASEURL = str(sys.argv[1])

# login
response = requests.post(BASEURL + '/api/users/login', json={
    'user': {
        'email': 'foo@foo.foo',
        'password': 'foofoo'
    }
}).json()

# Man: follow the guideline (accessed on Sep-06-2021)
# https://github.com/microsoft/restler-fuzzer/blob/main/docs/user-guide/Authentication.md

print("{'user':{}}")
print("Authorization: Token "+response['user']['token'])
