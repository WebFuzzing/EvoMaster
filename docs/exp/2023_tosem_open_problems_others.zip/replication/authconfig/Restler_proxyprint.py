#!/usr/bin/python

# https://github.com/microsoft/restler-fuzzer/blob/main/docs/user-guide/Authentication.md

print("{'user':{}}")
print("Authorization: Basic bWFzdGVyOjEyMzQ=")
